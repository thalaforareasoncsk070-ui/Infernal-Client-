# Infernal Client reference notes

The project may use Feather Legacy, Club, and Aoba as behavioral/architectural references only.

- Feather Legacy: reference for compact client branding, HUD/client UI presentation, and icon placement.
- Club: reference for client UI/icon organization and settings presentation.
- Aoba: reference for tracer module organization and target/range concepts.

Infernal uses its own implementation and its own logo asset. Do not copy proprietary source code or branding assets from the reference projects.

## Infernal branding

- `src/main/resources/assets/infernal/icon.png` is the supplied Infernal logo converted losslessly to PNG for Minecraft resource loading.
- The settings screen uses the supplied logo and a green Infernal visual theme.
- Compact client-name branding is intended to render the logo in a white/foreground presentation where the rendering path supports tinting.
