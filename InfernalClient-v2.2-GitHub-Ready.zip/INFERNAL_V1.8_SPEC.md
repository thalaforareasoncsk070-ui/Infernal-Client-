# Infernal Client v1.8 — UI/Branding Specification

## Branding
- Green Infernal branding is used for the client/settings experience.
- The settings landing screen shows a **round Infernal logo** centered prominently.
- Under the round logo, display **Infernal Client Settings**.
- The landing screen is an intermediate branded screen: the user clicks the logo to enter the settings UI.
- The settings UI should have a Lunar-style layout/feel, but use Infernal's own green visual theme and original assets.

## Nametag badge
- Infernal users should have a small **white Infernal symbol** immediately before their name in the nametag.
- The white badge must be compact and not obscure the player name.
- Client identification for other players requires an explicit client-identification mechanism; a client cannot infer another installed mod purely from the normal player entity.

## Version
- Target: Minecraft 26.2 / Fabric.
- Project version: Infernal Client 1.8.
