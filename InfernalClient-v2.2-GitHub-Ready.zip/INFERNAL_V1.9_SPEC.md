# Infernal Client v1.9

Target: Minecraft 26.2 / Fabric.

## Branding
- Green/black polished Infernal theme across client UI and inventory screens.
- Round Infernal logo on the Right Shift landing screen.
- White Infernal logo for client identity badges in nametags and chat.
- Preserve Minecraft readability and avoid excessive neon styling.

## Built-in Java resource pack
- Ship an Infernal resource pack with the client.
- Enable it automatically on first install/first launch where technically supported.
- Allow the user to disable or change it later.
- The resource pack supplies visual assets; client code supplies dynamic rendering such as crosshair color and client badges.

## Infernal client detection
- Implement a small client-identification handshake between Infernal clients.
- Only display the Infernal badge for players who explicitly identify as Infernal.
- Do not claim that a normal Minecraft client can detect another installed client without an identification mechanism.
- Avoid transmitting unnecessary player information.

## Nametags/chat
Infernal users:
  [white Infernal logo] PlayerName

The same badge presentation should be available in chat name rendering.

## PvP resource-pack visuals
- Small fire overlay.
- Compact shield overlay.
- Small totem and compact totem-pop visual.
- Connecting-glass visual treatment where supported.
- Numbered hotbar.
- Clean GUI.
- Green/black inventory and menu theme.

## Crosshair
- Same size/shape in both states.
- Normal color when not targeting a hittable target.
- Green when the crosshair raycast is targeting a hittable entity/object.

## Bedrock resource pack
- Provide a separate Bedrock-compatible pack.
- Use the same green/black Infernal identity.
- Include compact fire/shield/totem visuals, numbered hotbar styling where Bedrock permits, and compatible GUI textures.
- Bedrock pack cannot implement Java client-only logic such as the Java handshake or dynamic crosshair targeting unless Bedrock-side scripting/add-ons are separately used.
