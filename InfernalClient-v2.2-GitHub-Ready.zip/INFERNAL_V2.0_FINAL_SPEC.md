# INFERNAL CLIENT 2.0 — FINAL RELEASE SPECIFICATION

Target: Minecraft 26.2 / Fabric.

## Product direction
Infernal 2.0 is the polished final release target. The UI should feel cohesive and premium rather than like a pile of unrelated mods:
- green + black visual system
- restrained animations
- clean typography and spacing
- consistent icons
- responsive settings navigation
- performance-first defaults

## Core client features
### Branding / UI
- Round Infernal logo landing screen after Right Shift.
- "Infernal Client Settings" beneath the logo.
- Click logo to enter the settings dashboard.
- Green/black Lunar-inspired layout using original Infernal branding.
- Inventory and menu styling aligned with the same visual system.
- White Infernal client badge for supported nametags and chat.

### PvP / HUD
- Player tracers with configurable radius and color.
- 10-chunk tracer target range requirement from earlier design.
- Armor HUD.
- Potion/effect HUD.
- Totem counter and compact pop effect.
- CPS/FPS display.
- Coordinates and keystrokes.
- Custom crosshair.
- Crosshair turns green while retaining identical size/shape when the raycast targets a hittable entity/object.
- Numbered hotbar.
- Compact fire and shield overlays.
- Compact totem.
- Clean hit indicators where compatible.

### Motion / visual effects
- Configurable motion blur with low/medium/high/off presets.
- Blur should not make the entire sprint view excessively blurry.
- UI transitions kept subtle.
- Optional screen effects should be disabled by default on low-end devices.

### Performance / FPS mode
Provide a dedicated Performance page with:
- fast render path where compatible
- reduced unnecessary animation work
- entity/render-distance-aware optimizations
- particle-density controls
- weather/visual-effect reduction options
- smart GUI rendering
- chunk/render scheduling improvements where safe
- optional dynamic performance profile

IMPORTANT: FPS cannot be guaranteed to jump from 30 to 60/100 on every device. The client should expose safe optimizations and measure the actual FPS. Target is to reduce client overhead and improve consistency, not promise a fixed FPS.

### Infernal client identification
- Explicit client-to-client/server handshake.
- Other Infernal users can advertise Infernal support.
- Display the white Infernal badge only for positively identified Infernal clients.
- Do not attempt to infer installed clients from ordinary player data.

### Built-in resource pack
- Ship the Infernal Java resource pack with the client.
- Offer automatic first-launch enablement.
- Allow users to disable/replace it.
- Include compact fire/shield/totem, numbered hotbar, green/black GUI and Infernal branding.

### Bedrock
- Maintain a separate Bedrock-compatible visual pack.
- Do not claim Java-only client logic is provided by a resource pack.

## Quality bar
Before calling the release finished:
1. Build successfully on a clean Java 25 environment.
2. Launch Minecraft 26.2 successfully.
3. Test with the intended Fabric API version.
4. Verify settings screen opens and closes repeatedly.
5. Verify all keybinds have conflict-safe defaults.
6. Verify disabling every optional visual feature works.
7. Test a low-end performance profile.
8. Test with other common Fabric performance/UI mods for conflicts.
9. Check logs for errors/warnings introduced by Infernal.
10. Verify resource-pack assets are present and load.
11. Verify client-identification fallback when another player is not Infernal.
12. Package a reproducible GitHub Actions build.

## Release artifacts
- infernalclient-2.0.0+26.2.jar
- Infernal-Visuals-Java-2.0.zip
- Infernal-Visuals-Bedrock-2.0.mcpack
