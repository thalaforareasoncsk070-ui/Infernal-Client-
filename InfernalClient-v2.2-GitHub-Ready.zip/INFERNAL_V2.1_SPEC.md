# Infernal Client 2.1

## Release branding
- Version: 2.1.0
- Minecraft: 26.2
- Fabric Loader: 0.19.3
- Theme: green/black
- Canonical logo asset: assets/infernal/infernal_logo.png

## Infernal presence
The client may render Infernal branding locally. Cross-client discovery (one Infernal client identifying another) requires a server-mediated protocol/plugin or a compatible shared resource/metadata mechanism. A client-only Fabric mod cannot directly discover another client behind a vanilla server.

This release therefore does not falsely claim universal server-side detection.
