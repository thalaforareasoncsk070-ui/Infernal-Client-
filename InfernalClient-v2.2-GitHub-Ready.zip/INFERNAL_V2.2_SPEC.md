# Infernal Client 2.2 — Reference-informed build

Target: Minecraft 26.2 / Fabric.

## Reference-informed design
- Feather Remake: lightweight client-side HUD/settings organization, Right Shift settings flow, and modular utility-client presentation.
- Aoba: modular client architecture and tracer behavior concepts.
- Aoba Tracer: tracer settings model (target types, colors, max lines, and display mode) used only as a high-level behavioral reference.

No third-party source code, assets, or proprietary implementation is copied into Infernal.

## Infernal additions
- Green/black client identity.
- Canonical circular Infernal logo.
- White logo asset for compact branding.
- Tracer module foundation with configurable target categories.
- Architecture ready for an optional Infernal-to-Infernal presence protocol; universal detection through a vanilla server is not claimed.
