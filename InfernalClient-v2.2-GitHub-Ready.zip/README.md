# Infernal Client 2.2 — Minecraft 26.2 Fabric

JAVA ONLY. This project is separate from the Bedrock project.

Target:
- Minecraft 26.2
- Fabric Loader 0.19.3
- Fabric API 0.153.0+26.2
- Fabric Loom 1.16.2
- Gradle 9.5.1+
- Java 25

## Controls
- Right Shift: open Infernal Client settings
- C: zoom key state

## Included client modules/foundations
- Lunar-style dark settings screen
- FPS Boost configuration foundation
- FPS counter
- CPS counter configuration foundation
- Ping counter
- Armor HUD
- Potion counter
- Totem counter
- Arrow counter
- Custom crosshair
- Fullbright configuration foundation
- Numbered hotbar configuration foundation
- Freelook configuration foundation
- Motion blur configuration foundation
- Entity Tracer setting and rendering integration point

All modules are intended to be client-side.

## Performance
Infernal's own UI/HUD is lightweight. Real FPS gains should come from
carefully chosen rendering/performance changes; claiming a fixed FPS increase
without benchmarking the user's device would be misleading.

## Build
Use JDK 25 and Gradle/Loom. Loom obtains the Minecraft development dependency
and mappings. Run:

    ./gradlew build

The output JAR will be in:

    build/libs/

This chat runtime cannot execute the external Gradle/Loom dependency download,
so this archive is not being represented as a compiled/verified JAR.

## Branding references

See `REFERENCES.md`. The supplied Infernal logo is included at `src/main/resources/assets/infernal/icon.png` and is registered as the Fabric mod icon.

## Reference-informed design
Infernal 2.2 takes high-level UI/module architecture inspiration from public descriptions of Feather Remake and Aoba, including the general concept of a modular client, configurable HUDs, and tracer settings. No third-party source code is copied. See INFERNAL_V2.2_SPEC.md.
