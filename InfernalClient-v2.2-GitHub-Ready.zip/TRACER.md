# Entity Tracer

Infernal exposes an `Entity Tracer` client setting.

Minecraft 26.2 changed its rendering architecture: world rendering is split
into extraction and drawing phases and the supported approach uses Blaze3D/
RenderPipeline APIs rather than raw OpenGL. Fabric's 26.2 documentation shows
the supported pipeline for rendering through-wall waypoints.

The setting is therefore included in the client UI, while the final dynamic
entity-line renderer is isolated as the next rendering module. This avoids
shipping an untested raw-OpenGL implementation into a 26.2 client.

When implemented, it should remain purely visual/client-side: it draws a line
from the player's camera to selected entity render states and does not send
packets or modify server state.
