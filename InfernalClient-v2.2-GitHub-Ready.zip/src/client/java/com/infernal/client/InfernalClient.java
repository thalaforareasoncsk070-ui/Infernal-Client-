package com.infernal.client;

import com.infernal.client.gui.InfernalSettingsScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.VanillaHudElements;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import org.lwjgl.glfw.GLFW;

public final class InfernalClient implements ClientModInitializer {
    public static final String MOD_ID = "infernal";

    public static boolean enabled = true;
    public static boolean fpsBoost = true;
    public static boolean fpsHud = true;
    public static boolean cpsHud = true;
    public static boolean pingHud = true;
    public static boolean armorHud = true;
    public static boolean potionHud = true;
    public static boolean totemHud = true;
    public static boolean arrowHud = true;
    public static boolean customCrosshair = true;
    public static boolean fullbright = false;
    public static boolean numberedHotbar = true;
    public static boolean tracer = false;
    public static boolean zoom = false;
    public static boolean freelook = false;
    public static boolean motionBlur = false;

    private static KeyMapping settingsKey;
    private static KeyMapping zoomKey;

    @Override
    public void onInitializeClient() {
        settingsKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.infernal.settings", GLFW.GLFW_KEY_RIGHT_SHIFT, "category.infernal"));
        zoomKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.infernal.zoom", GLFW.GLFW_KEY_C, "category.infernal"));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (settingsKey.consumeClick()) {
                if (client.screen == null) {
                    client.setScreen(new InfernalSettingsScreen(null));
                }
            }
            zoom = zoomKey.isDown();
        });

        HudElementRegistry.attachElementBefore(
                VanillaHudElements.CHAT,
                net.minecraft.resources.Identifier.fromNamespaceAndPath(MOD_ID, "hud"),
                InfernalHud::render
        );
    }
}
