package com.infernal.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.item.ItemStack;

public final class InfernalHud {
    private InfernalHud() {}

    public static void render(GuiGraphicsExtractor g, DeltaTracker tickCounter) {
        Minecraft mc = Minecraft.getInstance();
        if (!InfernalClient.enabled || mc.player == null) return;

        int x = 8;
        int y = 8;
        int line = 12;

        if (InfernalClient.fpsHud) {
            g.text(mc.font, "FPS: " + mc.getFps(), x, y, 0xFFFFFFFF, true);
            y += line;
        }
        if (InfernalClient.pingHud && mc.getConnection() != null) {
            var entry = mc.getConnection().getPlayerInfo(mc.player.getUUID());
            if (entry != null) {
                g.text(mc.font, "Ping: " + entry.getLatency(), x, y, 0xFFFFFFFF, true);
                y += line;
            }
        }
        if (InfernalClient.armorHud) {
            g.text(mc.font, "Armor: " + armorCount(mc), x, y, 0xFFFFFFFF, true);
            y += line;
        }
        if (InfernalClient.potionHud) {
            g.text(mc.font, "Potions: " + effectCount(mc), x, y, 0xFFFFFFFF, true);
            y += line;
        }
        if (InfernalClient.arrowHud) {
            g.text(mc.font, "Arrows: " + countItem(mc, "arrow"), x, y, 0xFFFFFFFF, true);
            y += line;
        }
        if (InfernalClient.totemHud) {
            g.text(mc.font, "Totems: " + countItem(mc, "totem_of_undying"), x, y, 0xFFFFFFFF, true);
        }

        if (InfernalClient.customCrosshair) {
            int cx = mc.getWindow().getGuiScaledWidth() / 2;
            int cy = mc.getWindow().getGuiScaledHeight() / 2;
            g.fill(cx - 5, cy - 1, cx + 5, cy + 1, 0xFFFFFFFF);
            g.fill(cx - 1, cy - 5, cx + 1, cy + 5, 0xFFFFFFFF);
        }
    }

    private static int armorCount(Minecraft mc) {
        int n = 0;
        for (ItemStack s : mc.player.getArmorSlots()) if (!s.isEmpty()) n++;
        return n;
    }

    private static int effectCount(Minecraft mc) {
        int n = 0;
        for (MobEffectInstance ignored : mc.player.getActiveEffects()) n++;
        return n;
    }

    private static int countItem(Minecraft mc, String id) {
        int n = 0;
        for (ItemStack s : mc.player.getInventory().items)
            if (s.getItem().toString().contains(id)) n += s.getCount();
        return n;
    }
}
