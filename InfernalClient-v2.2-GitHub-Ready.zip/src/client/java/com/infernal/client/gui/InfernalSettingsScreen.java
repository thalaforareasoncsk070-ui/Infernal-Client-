package com.infernal.client.gui;

import com.infernal.client.InfernalClient;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;

public final class InfernalSettingsScreen extends Screen {
    private final Screen parent;

    public InfernalSettingsScreen(Screen parent) {
        super(Component.literal("Infernal Client"));
        this.parent = parent;
    }

    private static final Identifier LOGO = Identifier.fromNamespaceAndPath(InfernalClient.MOD_ID, "icon");

    @Override
    protected void init() {
        int center = this.width / 2;
        int y = 55;

        addToggle(center, y, "FPS Boost", () -> InfernalClient.fpsBoost, v -> InfernalClient.fpsBoost = v); y += 24;
        addToggle(center, y, "FPS Counter", () -> InfernalClient.fpsHud, v -> InfernalClient.fpsHud = v); y += 24;
        addToggle(center, y, "CPS Counter", () -> InfernalClient.cpsHud, v -> InfernalClient.cpsHud = v); y += 24;
        addToggle(center, y, "Ping Counter", () -> InfernalClient.pingHud, v -> InfernalClient.pingHud = v); y += 24;
        addToggle(center, y, "Armor HUD", () -> InfernalClient.armorHud, v -> InfernalClient.armorHud = v); y += 24;
        addToggle(center, y, "Potion Counter", () -> InfernalClient.potionHud, v -> InfernalClient.potionHud = v); y += 24;
        addToggle(center, y, "Totem Counter", () -> InfernalClient.totemHud, v -> InfernalClient.totemHud = v); y += 24;
        addToggle(center, y, "Arrow Counter", () -> InfernalClient.arrowHud, v -> InfernalClient.arrowHud = v); y += 24;
        addToggle(center, y, "Custom Crosshair", () -> InfernalClient.customCrosshair, v -> InfernalClient.customCrosshair = v); y += 24;
        addToggle(center, y, "Fullbright", () -> InfernalClient.fullbright, v -> InfernalClient.fullbright = v); y += 24;
        addToggle(center, y, "Numbered Hotbar", () -> InfernalClient.numberedHotbar, v -> InfernalClient.numberedHotbar = v); y += 24;
        addToggle(center, y, "Entity Tracer", () -> InfernalClient.tracer, v -> InfernalClient.tracer = v); y += 24;
        addToggle(center, y, "Freelook", () -> InfernalClient.freelook, v -> InfernalClient.freelook = v); y += 24;
        addToggle(center, y, "Motion Blur", () -> InfernalClient.motionBlur, v -> InfernalClient.motionBlur = v); y += 28;

        addRenderableWidget(Button.builder(Component.literal("Done"), b -> onClose())
                .bounds(center - 110, this.height - 27, 220, 20).build());
    }

    private void addToggle(int center, int y, String name, BoolGetter getter, BoolSetter setter) {
        Button b = Button.builder(label(name, getter.get()), button -> {
            setter.set(!getter.get());
            button.setMessage(label(name, getter.get()));
        }).bounds(center - 110, y, 220, 20).build();
        addRenderableWidget(b);
    }

    private static Component label(String name, boolean on) {
        return Component.literal(name + ": " + (on ? "ON" : "OFF"));
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        super.extractRenderState(g, mouseX, mouseY, delta);
        g.fill(0, 0, width, height, 0xE6062508);
        g.fill(width / 2 - 145, 0, width / 2 + 145, height, 0xD90A3D0A);
        g.blit(LOGO, width / 2 - 16, 4, 0, 0, 32, 32, 32, 32);
        g.text(font, "INFERNAL CLIENT", width / 2 - 66, 38, 0xFFFFFFFF, true);
        g.text(font, "Performance • HUD • Visuals", width / 2 - 86, 54, 0xFFFFFFFF, false);
    }

    @Override
    public void onClose() {
        if (minecraft != null) minecraft.setScreen(parent);
    }

    @FunctionalInterface private interface BoolGetter { boolean get(); }
    @FunctionalInterface private interface BoolSetter { void set(boolean value); }
}
